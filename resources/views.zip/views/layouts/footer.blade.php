<!-- Footer -->
<section class="cid-rsuhG4Y4Z6 custom-footer margin-top-150" id="footer1-f">
    <div class="container">
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-lg-12 col-sm-12 row justify-content-center">
                  <div class="col-3 footer-rwd mbr-fonts-style display-7 text-align-center" >
                    <a href="{{ route('aboutus') }}" class="pb-3 footer-font-a">
                        Liên quan tới chúng tôi
                    </a>
                  </div>
                  <div class="col-2  footer-rwd mbr-fonts-style display-7 text-align-center" >
                    <a href="{{ route('service') }}" class="pb-3 footer-font-b">
                        Điều khoản dịch vụ 
                    </a>
                  </div>
                  <div class="col-2 footer-rwd mbr-fonts-style display-7 text-align-center">
                    <a href="{{ route('fq') }}" class="pb-3 footer-font-c">
                        Vấn đề thường gặp
                    </a>
                  </div>

                  <div class="col-2 footer-rwd mbr-fonts-style display-7 text-align-center">
                    <a href="{{ route('privacy') }}" class="pb-3 footer-font-d">
                        Chính sách riêng tư 
                    </a>
                  </div>
                  <div class="col-3 footer-rwd mbr-fonts-style display-7 text-align-center">
                    <a href="{{ route('contact_us')}}" class="pb-3 footer-font-e">
                        Liên hệ với chúng tôi
                    </a>
                  </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="cid-rsuhG4Y4Z6 my-4 " id="footer1-f" style="background-color:white; padding:20px 0px;"></section>

